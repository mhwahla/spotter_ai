# Freight Rate Prediction

This project predicts freight prices using the supplied load data.

## Approach

Models are trained on January-June and compared on July-August.
The selected models are then tested on September-October after
training on January-August. Final models use all 48,000 labeled loads.

The main model is `ridge_full`. The December chart uses
`boosting_core` because its inputs lack market_index and quote_signal.

Non-positive weights become missing. Missing numerical inputs are
filled using training medians. Scaling and categorical encoding are
fitted only on training data. Unknown city names are handled by the
encoder. Expensive loads are retained.

## Internal-test results

Main model MAE: $124.28
Main model RMSE: $638.13
Main model median absolute error: $46.59
Main model MAPE: 5.30%
Baseline MAE: $256.95

The main model improves MAE by 51.6% over the baseline.
Final November-December accuracy is unknown because labels are absent.

## Run

1. Install the packages:

   python -m pip install -r solution-requirements.txt

2. Open assessment.ipynb in Jupyter.
3. Restart the kernel and run all cells in order.
4. The notebook creates predictions, runs score.py, and builds the report.

To run the scorer separately:

python score.py --predictions outputs/validation_predictions.csv --december-predictions outputs/december_chart_inputs.csv --output-dir outputs/scorer_results

The supplied scorer checks output format and creates the chart.
Spotter calculates final prediction accuracy.

## Outputs

- outputs/validation_predictions.csv
- outputs/december_chart_inputs.csv
- outputs/scorer_results/candidate_december.png
- outputs/freight_rate_report.pdf
- outputs/model_comparison.csv
- outputs/final_test_metrics.csv
- outputs/internal_test_predictions.csv
- outputs/metrics.json
- outputs/models.joblib

The original input CSVs remain unchanged in data/.

## Limitations

Large price outliers still cause substantial errors. Unfamiliar cities
and future seasonality are additional concerns. The two extra signals
are supplied but their origins are undocumented.

## Submission

Publish an accessible GitHub repository containing the notebook,
dependencies, and run instructions. Submit the prediction file and
report, and record a 2-3 minute Loom explaining the solution.
Follow the assessment rules about assistance and describe your
contribution accurately.
